package com.avengers.items.heroes;

import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.RaycastContext;

public class SpiderWebshooterItem extends Item {

    public SpiderWebshooterItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient) {
            if (player.isSneaking()) {
                // Web-swing: launch player forward at high speed
                Vec3d look = player.getRotationVec(1.0f);
                player.addVelocity(look.x * 2.5, look.y * 2.5, look.z * 2.5);
                player.fallDistance = 0;
                world.playSound(null, player.getBlockPos(),
                        SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 0.5f, 2.0f);
            } else {
                // Shoot cobweb at target block
                Vec3d start = player.getEyePos();
                Vec3d end = start.add(player.getRotationVec(1.0f).multiply(20.0));
                HitResult hit = world.raycast(new RaycastContext(
                        start, end, RaycastContext.ShapeType.OUTLINE,
                        RaycastContext.FluidHandling.NONE, player));
                if (hit.getType() == HitResult.Type.BLOCK) {
                    BlockPos pos = ((BlockHitResult) hit).getBlockPos().offset(((BlockHitResult) hit).getSide());
                    if (world.isAir(pos)) {
                        world.setBlockState(pos, Blocks.COBWEB.getDefaultState());
                        world.playSound(null, pos,
                                SoundEvents.BLOCK_WOOL_PLACE, SoundCategory.PLAYERS, 1.0f, 1.2f);
                    }
                }
            }
            stack.damage(1, player, net.minecraft.entity.EquipmentSlot.MAINHAND);
        }
        player.getItemCooldownManager().set(this, 10);
        return TypedActionResult.success(stack);
    }
}
