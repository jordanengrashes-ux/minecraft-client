package com.avengers.items.stones;

import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class RealityStoneItem extends BaseStoneItem {

    public RealityStoneItem(Settings settings) {
        super(settings);
    }

    @Override
    protected void activatePower(World world, PlayerEntity player) {
        if (!(world instanceof ServerWorld sw)) return;

        // Warp reality around the player — convert nearby blocks to random alternatives
        BlockPos center = player.getBlockPos();
        int radius = 5;
        net.minecraft.block.BlockState[] states = {
                Blocks.GOLD_BLOCK.getDefaultState(),
                Blocks.DIAMOND_BLOCK.getDefaultState(),
                Blocks.EMERALD_BLOCK.getDefaultState(),
                Blocks.OBSIDIAN.getDefaultState(),
                Blocks.NETHERRACK.getDefaultState(),
        };

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    BlockPos pos = center.add(dx, dy, dz);
                    if (!world.isAir(pos) && !world.getBlockState(pos).isOf(Blocks.BEDROCK)) {
                        if (world.getRandom().nextFloat() < 0.15f) {
                            world.setBlockState(pos, states[world.getRandom().nextInt(states.length)]);
                        }
                    }
                }
            }
        }

        sw.spawnParticles(ParticleTypes.CRIMSON_SPORE,
                player.getX(), player.getY() + 1, player.getZ(), 60, 3.0, 3.0, 3.0, 0.1);
        world.playSound(null, player.getBlockPos(),
                SoundEvents.ENTITY_ENDER_DRAGON_DEATH, SoundCategory.PLAYERS, 0.4f, 1.5f);
    }

    @Override
    protected int getCooldown() { return 400; }
}
