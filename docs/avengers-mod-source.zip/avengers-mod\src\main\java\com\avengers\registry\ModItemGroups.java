package com.avengers.registry;

import com.avengers.AvengersMain;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ModItemGroups {

    public static final ItemGroup AVENGERS_GROUP = Registry.register(
            Registries.ITEM_GROUP,
            Identifier.of(AvengersMain.MOD_ID, "avengers"),
            FabricItemGroup.builder()
                    .displayName(Text.translatable("itemGroup.avengers.avengers"))
                    .icon(() -> new ItemStack(ModItems.INFINITY_GAUNTLET))
                    .entries((context, entries) -> {
                        // Hero gear
                        entries.add(ModItems.IRONMAN_HELMET);
                        entries.add(ModItems.IRONMAN_CHESTPLATE);
                        entries.add(ModItems.IRONMAN_LEGGINGS);
                        entries.add(ModItems.IRONMAN_BOOTS);
                        entries.add(ModItems.MJOLNIR);
                        entries.add(ModItems.CAPTAIN_SHIELD);
                        entries.add(ModItems.HULK_SERUM);
                        entries.add(ModItems.BLACK_WIDOW_BATONS);
                        entries.add(ModItems.HAWKEYE_BOW);
                        entries.add(ModItems.SCARLET_WITCH_WAND);
                        entries.add(ModItems.STRANGE_SLINGER);
                        entries.add(ModItems.SPIDER_WEBSHOOTER);
                        entries.add(ModItems.BLACK_PANTHER_HELMET);
                        entries.add(ModItems.BLACK_PANTHER_CHESTPLATE);
                        entries.add(ModItems.BLACK_PANTHER_LEGGINGS);
                        entries.add(ModItems.BLACK_PANTHER_BOOTS);
                        entries.add(ModItems.BLACK_PANTHER_CLAWS);
                        entries.add(ModItems.PYM_PARTICLES);
                        entries.add(ModItems.VISION_GEM);
                        entries.add(ModItems.FALCON_WINGS);
                        entries.add(ModItems.WINTER_SOLDIER_ARM);
                        // Infinity Stones
                        entries.add(ModItems.POWER_STONE);
                        entries.add(ModItems.MIND_STONE);
                        entries.add(ModItems.SOUL_STONE);
                        entries.add(ModItems.TIME_STONE);
                        entries.add(ModItems.SPACE_STONE);
                        entries.add(ModItems.REALITY_STONE);
                        entries.add(ModItems.INFINITY_GAUNTLET);
                    })
                    .build()
    );

    public static void initialize() {}
}
