package com.avengers.registry;

import com.avengers.AvengersMain;
import com.avengers.items.heroes.*;
import com.avengers.items.stones.*;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public class ModItems {

    // --- Iron Man suit (4 pieces) ---
    public static final IronManHelmetItem IRONMAN_HELMET =
            register("ironman_helmet", new IronManHelmetItem(ModArmorMaterials.IRON_MAN,
                    new Item.Settings().maxDamage(1200)));
    public static final IronManChestplateItem IRONMAN_CHESTPLATE =
            register("ironman_chestplate", new IronManChestplateItem(ModArmorMaterials.IRON_MAN,
                    new Item.Settings().maxDamage(1600)));
    public static final ArmorItem IRONMAN_LEGGINGS =
            register("ironman_leggings", new ArmorItem(ModArmorMaterials.IRON_MAN,
                    ArmorItem.Type.LEGGINGS, new Item.Settings().maxDamage(1500)));
    public static final ArmorItem IRONMAN_BOOTS =
            register("ironman_boots", new ArmorItem(ModArmorMaterials.IRON_MAN,
                    ArmorItem.Type.BOOTS, new Item.Settings().maxDamage(1300)));

    // --- Thor ---
    public static final MjolnirItem MJOLNIR =
            register("mjolnir", new MjolnirItem(new Item.Settings().maxDamage(2000)));

    // --- Captain America ---
    public static final CaptainShieldItem CAPTAIN_SHIELD =
            register("captain_shield", new CaptainShieldItem(new Item.Settings().maxDamage(2500)));

    // --- Hulk ---
    public static final HulkSerumItem HULK_SERUM =
            register("hulk_serum", new HulkSerumItem(new Item.Settings().maxCount(1)));

    // --- Black Widow ---
    public static final BlackWidowBatonsItem BLACK_WIDOW_BATONS =
            register("black_widow_batons", new BlackWidowBatonsItem(new Item.Settings().maxDamage(800)));

    // --- Hawkeye ---
    public static final HawkeyeBowItem HAWKEYE_BOW =
            register("hawkeye_bow", new HawkeyeBowItem(new Item.Settings().maxDamage(500)));

    // --- Scarlet Witch ---
    public static final ScarletWitchWandItem SCARLET_WITCH_WAND =
            register("scarlet_witch_wand", new ScarletWitchWandItem(new Item.Settings().maxDamage(1000)));

    // --- Doctor Strange ---
    public static final StrangeSlingerItem STRANGE_SLINGER =
            register("strange_slinger", new StrangeSlingerItem(new Item.Settings().maxDamage(500)));

    // --- Spider-Man ---
    public static final SpiderWebshooterItem SPIDER_WEBSHOOTER =
            register("spider_webshooter", new SpiderWebshooterItem(new Item.Settings().maxDamage(300)));

    // --- Black Panther suit (4 pieces) ---
    public static final BlackPantherHelmetItem BLACK_PANTHER_HELMET =
            register("black_panther_helmet", new BlackPantherHelmetItem(ModArmorMaterials.BLACK_PANTHER,
                    new Item.Settings().maxDamage(1200)));
    public static final BlackPantherChestplateItem BLACK_PANTHER_CHESTPLATE =
            register("black_panther_chestplate", new BlackPantherChestplateItem(ModArmorMaterials.BLACK_PANTHER,
                    new Item.Settings().maxDamage(1600)));
    public static final ArmorItem BLACK_PANTHER_LEGGINGS =
            register("black_panther_leggings", new ArmorItem(ModArmorMaterials.BLACK_PANTHER,
                    ArmorItem.Type.LEGGINGS, new Item.Settings().maxDamage(1500)));
    public static final ArmorItem BLACK_PANTHER_BOOTS =
            register("black_panther_boots", new ArmorItem(ModArmorMaterials.BLACK_PANTHER,
                    ArmorItem.Type.BOOTS, new Item.Settings().maxDamage(1300)));
    public static final BlackPantherClawsItem BLACK_PANTHER_CLAWS =
            register("black_panther_claws", new BlackPantherClawsItem(new Item.Settings().maxDamage(1000)));

    // --- Ant-Man ---
    public static final PymParticlesItem PYM_PARTICLES =
            register("pym_particles", new PymParticlesItem(new Item.Settings().maxCount(16)));

    // --- Vision ---
    public static final VisionGemItem VISION_GEM =
            register("vision_gem", new VisionGemItem(new Item.Settings().maxDamage(800)));

    // --- Falcon ---
    public static final FalconWingsItem FALCON_WINGS =
            register("falcon_wings", new FalconWingsItem(ModArmorMaterials.FALCON,
                    new Item.Settings().maxDamage(900)));

    // --- Winter Soldier ---
    public static final WinterSoldierArmItem WINTER_SOLDIER_ARM =
            register("winter_soldier_arm", new WinterSoldierArmItem(new Item.Settings().maxDamage(1500)));

    // --- Infinity Stones ---
    public static final PowerStoneItem POWER_STONE =
            register("power_stone", new PowerStoneItem(new Item.Settings().maxCount(1)));
    public static final MindStoneItem MIND_STONE =
            register("mind_stone", new MindStoneItem(new Item.Settings().maxCount(1)));
    public static final SoulStoneItem SOUL_STONE =
            register("soul_stone", new SoulStoneItem(new Item.Settings().maxCount(1)));
    public static final TimeStoneItem TIME_STONE =
            register("time_stone", new TimeStoneItem(new Item.Settings().maxCount(1)));
    public static final SpaceStoneItem SPACE_STONE =
            register("space_stone", new SpaceStoneItem(new Item.Settings().maxCount(1)));
    public static final RealityStoneItem REALITY_STONE =
            register("reality_stone", new RealityStoneItem(new Item.Settings().maxCount(1)));

    // --- Infinity Gauntlet ---
    public static final InfinityGauntletItem INFINITY_GAUNTLET =
            register("infinity_gauntlet", new InfinityGauntletItem(new Item.Settings().maxCount(1)));

    private static <T extends Item> T register(String name, T item) {
        return Registry.register(Registries.ITEM, Identifier.of(AvengersMain.MOD_ID, name), item);
    }

    public static boolean hasFullIronManSuit(ServerPlayerEntity player) {
        return player.getInventory().getArmorStack(3).isOf(IRONMAN_HELMET)
                && player.getInventory().getArmorStack(2).isOf(IRONMAN_CHESTPLATE)
                && player.getInventory().getArmorStack(1).isOf(IRONMAN_LEGGINGS)
                && player.getInventory().getArmorStack(0).isOf(IRONMAN_BOOTS);
    }

    public static boolean hasFalconWings(ServerPlayerEntity player) {
        return player.getInventory().getArmorStack(2).isOf(FALCON_WINGS);
    }

    public static void initialize() {
        ModArmorMaterials.initialize();
    }
}
