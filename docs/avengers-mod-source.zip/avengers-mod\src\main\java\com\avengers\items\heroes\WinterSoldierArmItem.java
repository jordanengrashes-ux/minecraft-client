package com.avengers.items.heroes;

import com.avengers.AvengersMain;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.ItemAttributeModifiers;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import net.minecraft.util.Identifier;

public class WinterSoldierArmItem extends Item {

    public WinterSoldierArmItem(Settings settings) {
        super(settings.attributeModifiers(
                ItemAttributeModifiers.builder()
                        .add(EntityAttributes.GENERIC_ATTACK_DAMAGE,
                                new EntityAttributeModifier(
                                        Identifier.of(AvengersMain.MOD_ID, "winter_arm_damage"),
                                        9.0, EntityAttributeModifier.Operation.ADD_VALUE),
                                AttributeModifierSlot.MAINHAND)
                        .add(EntityAttributes.GENERIC_ATTACK_SPEED,
                                new EntityAttributeModifier(
                                        Identifier.of(AvengersMain.MOD_ID, "winter_arm_speed"),
                                        -1.6, EntityAttributeModifier.Operation.ADD_VALUE),
                                AttributeModifierSlot.MAINHAND)
                        .build()
        ));
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient) {
            // Grapple: pull player toward the targeted block
            Vec3d start = player.getEyePos();
            Vec3d end = start.add(player.getRotationVec(1.0f).multiply(25.0));
            HitResult hit = world.raycast(new RaycastContext(
                    start, end, RaycastContext.ShapeType.OUTLINE,
                    RaycastContext.FluidHandling.NONE, player));
            if (hit.getType() == HitResult.Type.BLOCK) {
                Vec3d target = ((BlockHitResult) hit).getPos();
                Vec3d dir = target.subtract(player.getPos()).normalize();
                player.addVelocity(dir.x * 2.0, dir.y * 1.5 + 0.5, dir.z * 2.0);
                player.fallDistance = 0;
                world.playSound(null, player.getBlockPos(),
                        SoundEvents.ENTITY_FISHING_BOBBER_THROW, SoundCategory.PLAYERS, 1.0f, 1.5f);
                stack.damage(1, player, net.minecraft.entity.EquipmentSlot.MAINHAND);
            }
        }
        player.getItemCooldownManager().set(this, 20);
        return TypedActionResult.success(stack);
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        stack.damage(1, attacker, net.minecraft.entity.EquipmentSlot.MAINHAND);
        return true;
    }
}
