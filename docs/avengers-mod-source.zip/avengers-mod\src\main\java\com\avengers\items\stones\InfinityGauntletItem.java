package com.avengers.items.stones;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;

import java.util.ArrayList;
import java.util.List;

public class InfinityGauntletItem extends Item {

    private static final int SNAP_RANGE = 64;

    public InfinityGauntletItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient) {
            if (player.isSneaking()) {
                snap(world, player);
            } else {
                // All-stones power burst
                allStonesBurst(world, player);
            }
        }
        player.getItemCooldownManager().set(this, 100);
        return TypedActionResult.success(stack);
    }

    private void snap(World world, PlayerEntity player) {
        if (!(world instanceof ServerWorld sw)) return;

        player.sendMessage(Text.literal("*SNAP*"), true);
        world.playSound(null, player.getBlockPos(),
                SoundEvents.ENTITY_ENDER_DRAGON_DEATH, SoundCategory.PLAYERS, 1.0f, 0.5f);

        List<Entity> nearby = new ArrayList<>(world.getOtherEntities(player,
                player.getBoundingBox().expand(SNAP_RANGE)));

        // Eliminate 50% of all non-player living entities
        int count = 0;
        for (Entity e : nearby) {
            if (e instanceof LivingEntity living && !(living instanceof PlayerEntity)) {
                if (world.getRandom().nextBoolean()) {
                    living.kill(sw);
                    count++;
                }
            }
        }

        sw.spawnParticles(ParticleTypes.FLASH,
                player.getX(), player.getY() + 1, player.getZ(), 1, 0, 0, 0, 0);

        player.sendMessage(Text.literal("Perfectly balanced, as all things should be. (" + count + " eliminated)"), false);
        player.getItemCooldownManager().set(this, 2400); // 2-minute cooldown after snap
    }

    private void allStonesBurst(World world, PlayerEntity player) {
        if (!(world instanceof ServerWorld sw)) return;

        // Massive area blast
        List<Entity> nearby = world.getOtherEntities(player, player.getBoundingBox().expand(20.0));
        for (Entity e : nearby) {
            if (e instanceof LivingEntity living && !(living instanceof PlayerEntity)) {
                living.damage(sw, world.getDamageSources().magic(), 20.0f);
                living.addVelocity(
                        (e.getX() - player.getX()) * 0.5,
                        1.5,
                        (e.getZ() - player.getZ()) * 0.5);
            }
        }
        sw.spawnParticles(ParticleTypes.EXPLOSION_EMITTER,
                player.getX(), player.getY(), player.getZ(), 5, 3.0, 1.0, 3.0, 0.1);
        world.playSound(null, player.getBlockPos(),
                SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.0f, 0.5f);
    }
}
