package com.avengers.items.heroes;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class IronManChestplateItem extends ArmorItem {

    private static final int COOLDOWN_TICKS = 20;

    public IronManChestplateItem(RegistryEntry<ArmorMaterial> material, Settings settings) {
        super(material, Type.CHESTPLATE, settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        if (hand != Hand.MAIN_HAND) return TypedActionResult.pass(player.getStackInHand(hand));
        // Repulsor blast — only fires when the chestplate is equipped (in armor slot)
        // This method fires when the chestplate is held in hand; real use is via inventoryTick.
        // Keeping here for give-in-hand testing.
        if (!world.isClient) {
            fireRepulsor(player, (ServerWorld) world);
        }
        return TypedActionResult.success(player.getStackInHand(hand));
    }

    public static void fireRepulsor(PlayerEntity player, ServerWorld world) {
        Vec3d look = player.getRotationVec(1.0f);
        Vec3d pos = player.getEyePos();
        FireballEntity fireball = new FireballEntity(world, player,
                look.multiply(2.0), 1);
        fireball.setPosition(pos.x + look.x, pos.y + look.y, pos.z + look.z);
        world.spawnEntity(fireball);
        world.playSound(null, player.getBlockPos(),
                SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1.0f, 1.5f);
    }
}
