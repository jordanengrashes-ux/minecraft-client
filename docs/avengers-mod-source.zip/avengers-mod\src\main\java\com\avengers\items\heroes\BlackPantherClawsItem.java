package com.avengers.items.heroes;

import com.avengers.AvengersMain;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.ItemAttributeModifiers;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;

public class BlackPantherClawsItem extends Item {

    public BlackPantherClawsItem(Settings settings) {
        super(settings.attributeModifiers(
                ItemAttributeModifiers.builder()
                        .add(EntityAttributes.GENERIC_ATTACK_DAMAGE,
                                new EntityAttributeModifier(
                                        Identifier.of(AvengersMain.MOD_ID, "claw_damage"),
                                        7.0, EntityAttributeModifier.Operation.ADD_VALUE),
                                AttributeModifierSlot.MAINHAND)
                        .add(EntityAttributes.GENERIC_ATTACK_SPEED,
                                new EntityAttributeModifier(
                                        Identifier.of(AvengersMain.MOD_ID, "claw_speed"),
                                        2.0, EntityAttributeModifier.Operation.ADD_VALUE),
                                AttributeModifierSlot.MAINHAND)
                        .build()
        ));
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 0, false, true));
        stack.damage(1, attacker, net.minecraft.entity.EquipmentSlot.MAINHAND);
        return true;
    }
}
