package com.avengers.items.heroes;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

public class HawkeyeBowItem extends BowItem {

    public HawkeyeBowItem(Settings settings) {
        super(settings);
    }

    @Override
    public void onStoppedUsing(ItemStack stack, World world, net.minecraft.entity.LivingEntity user, int remainingUseTicks) {
        if (!world.isClient && user instanceof PlayerEntity player) {
            int useTicks = this.getMaxUseTime(stack, user) - remainingUseTicks;
            float power = BowItem.getPullProgress(useTicks);
            if (power < 0.1f) return;

            // Fire three spread arrows on full draw
            boolean tripleShot = power >= 1.0f;
            int count = tripleShot ? 3 : 1;
            float[] offsets = {0f, -5f, 5f};

            for (int i = 0; i < count; i++) {
                ArrowEntity arrow = new ArrowEntity(world, player, stack, null);
                arrow.setVelocity(player, player.getPitch() + offsets[i],
                        player.getYaw(), 0f, power * 3.0f, 1.0f);
                arrow.pickupType = ArrowEntity.PickupPermission.CREATIVE_ONLY;
                world.spawnEntity(arrow);
            }

            world.playSound(null, player.getBlockPos(),
                    SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.0f, 1.0f / (world.getRandom().nextFloat() * 0.4f + 1.2f) + power * 0.5f);
            stack.damage(1, player, net.minecraft.entity.EquipmentSlot.MAINHAND);
        }
    }
}
