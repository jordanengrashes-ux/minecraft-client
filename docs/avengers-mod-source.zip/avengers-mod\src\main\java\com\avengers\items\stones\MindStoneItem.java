package com.avengers.items.stones;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

public class MindStoneItem extends BaseStoneItem {

    public MindStoneItem(Settings settings) {
        super(settings);
    }

    @Override
    protected void activatePower(World world, PlayerEntity player) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 600, 3, false, true));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 600, 2, false, true));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 600, 0, false, false));
        world.playSound(null, player.getBlockPos(),
                SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0f, 0.5f);
    }
}
