package com.avengers.items.heroes;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.RaycastContext;

public class StrangeSlingerItem extends Item {

    private static final double PORTAL_RANGE = 30.0;

    public StrangeSlingerItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient) {
            Vec3d start = player.getEyePos();
            Vec3d end = start.add(player.getRotationVec(1.0f).multiply(PORTAL_RANGE));
            HitResult hit = world.raycast(new RaycastContext(
                    start, end, RaycastContext.ShapeType.OUTLINE,
                    RaycastContext.FluidHandling.NONE, player));

            Vec3d dest;
            if (hit.getType() == HitResult.Type.BLOCK) {
                dest = ((BlockHitResult) hit).getPos().add(0, 1, 0);
            } else {
                dest = end;
            }

            player.teleport((ServerWorld) world,
                    dest.x, dest.y, dest.z,
                    java.util.Set.of(),
                    player.getYaw(), player.getPitch());
            player.fallDistance = 0;

            // Spawn portal ring particles
            ServerWorld serverWorld = (ServerWorld) world;
            for (int i = 0; i < 24; i++) {
                double angle = (2 * Math.PI / 24) * i;
                serverWorld.spawnParticles(ParticleTypes.PORTAL,
                        dest.x + Math.cos(angle), dest.y + 1, dest.z + Math.sin(angle),
                        1, 0, 0, 0, 0.05);
            }
            world.playSound(null, player.getBlockPos(),
                    SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0f, 0.8f);
            stack.damage(1, player, net.minecraft.entity.EquipmentSlot.MAINHAND);
        }
        player.getItemCooldownManager().set(this, 40);
        return TypedActionResult.success(stack);
    }
}
