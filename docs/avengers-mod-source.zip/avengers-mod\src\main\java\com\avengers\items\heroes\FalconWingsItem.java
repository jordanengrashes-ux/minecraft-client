package com.avengers.items.heroes;

import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.World;

public class FalconWingsItem extends ArmorItem {

    public FalconWingsItem(RegistryEntry<ArmorMaterial> material, Settings settings) {
        super(material, Type.CHESTPLATE, settings);
    }

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if (!world.isClient && entity instanceof PlayerEntity player) {
            // Speed boost while wearing the wings
            player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.SPEED, 5, 0, false, false));
        }
    }
}
