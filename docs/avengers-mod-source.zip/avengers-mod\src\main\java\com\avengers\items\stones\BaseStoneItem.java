package com.avengers.items.stones;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public abstract class BaseStoneItem extends Item {

    public BaseStoneItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient) {
            activatePower(world, player);
        }
        player.getItemCooldownManager().set(this, getCooldown());
        return TypedActionResult.success(stack);
    }

    protected abstract void activatePower(World world, PlayerEntity player);

    protected int getCooldown() {
        return 40;
    }
}
