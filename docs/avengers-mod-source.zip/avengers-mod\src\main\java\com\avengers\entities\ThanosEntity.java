package com.avengers.entities;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ThanosEntity extends HostileEntity {

    private final ServerBossBar bossBar = new ServerBossBar(
            Text.literal("Thanos"), BossBar.Color.PURPLE, BossBar.Style.PROGRESS);

    private int snapCooldown = 0;

    public ThanosEntity(EntityType<? extends ThanosEntity> type, World world) {
        super(type, world);
        this.setHealth(500.0f);
        this.experiencePoints = 500;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 500.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 15.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.22)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0)
                .add(EntityAttributes.GENERIC_ARMOR, 10.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 64.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new MeleeAttackGoal(this, 1.2, true));
        this.goalSelector.add(2, new WanderAroundFarGoal(this, 0.8));
        this.goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 16.0f));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        bossBar.setPercent(this.getHealth() / this.getMaxHealth());

        // Phase 2: below 50% HP, throw boulders
        if (!this.getWorld().isClient && this.getHealth() < this.getMaxHealth() * 0.5f) {
            if (snapCooldown-- <= 0 && this.getTarget() != null) {
                throwBoulder();
                snapCooldown = 60;
            }
        }
    }

    private void throwBoulder() {
        if (this.getTarget() == null) return;
        Vec3d dir = this.getTarget().getPos().subtract(this.getPos()).normalize();
        SnowballEntity boulder = new SnowballEntity(this.getWorld(), this);
        boulder.setVelocity(dir.x * 2, dir.y * 2 + 0.3, dir.z * 2);
        this.getWorld().spawnEntity(boulder);
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        bossBar.removePlayer(player);
    }

    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_WITHER_AMBIENT; }

    @Override
    protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource source) {
        return SoundEvents.ENTITY_IRON_GOLEM_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_WITHER_DEATH; }
}
