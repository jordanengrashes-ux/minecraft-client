package com.avengers.entities;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class LokiEntity extends HostileEntity {

    private int teleportCooldown = 0;
    private int illusionCooldown = 0;

    public LokiEntity(EntityType<? extends LokiEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 100;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 120.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 8.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.32)
                .add(EntityAttributes.GENERIC_ARMOR, 6.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new MeleeAttackGoal(this, 1.4, true));
        this.goalSelector.add(2, new WanderAroundFarGoal(this, 1.0));
        this.goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 12.0f));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.getWorld().isClient) {
            // Teleport away when low on health
            if (teleportCooldown-- <= 0 && this.getHealth() < this.getMaxHealth() * 0.4f) {
                teleportRandom();
                teleportCooldown = 80;
            }
            // Spawn illusion (zombie) periodically
            if (illusionCooldown-- <= 0 && this.getTarget() != null) {
                spawnIllusion();
                illusionCooldown = 200;
            }
        }
    }

    private void teleportRandom() {
        double x = this.getX() + (this.getRandom().nextDouble() - 0.5) * 16;
        double z = this.getZ() + (this.getRandom().nextDouble() - 0.5) * 16;
        this.teleport(x, this.getY(), z);
        this.getWorld().playSound(null, this.getBlockPos(),
                SoundEvents.ENTITY_ENDERMAN_TELEPORT, net.minecraft.sound.SoundCategory.HOSTILE, 1.0f, 1.2f);
    }

    private void spawnIllusion() {
        if (!(this.getWorld() instanceof ServerWorld sw)) return;
        ZombieEntity illusion = EntityType.ZOMBIE.create(sw, SpawnReason.MOB_SUMMONED);
        if (illusion == null) return;
        illusion.setPosition(this.getPos().add(
                (this.getRandom().nextDouble() - 0.5) * 4, 0,
                (this.getRandom().nextDouble() - 0.5) * 4));
        illusion.setCustomName(net.minecraft.text.Text.literal("Loki Illusion"));
        sw.spawnEntity(illusion);
    }

    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_EVOKER_AMBIENT; }

    @Override
    protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource source) {
        return SoundEvents.ENTITY_EVOKER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_EVOKER_DEATH; }
}
