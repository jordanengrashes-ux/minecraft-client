package com.avengers.items.heroes;

import com.avengers.AvengersMain;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.ItemAttributeModifiers;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class CaptainShieldItem extends Item {

    public CaptainShieldItem(Settings settings) {
        super(settings.attributeModifiers(
                ItemAttributeModifiers.builder()
                        .add(EntityAttributes.GENERIC_ATTACK_DAMAGE,
                                new EntityAttributeModifier(
                                        Identifier.of(AvengersMain.MOD_ID, "shield_damage"),
                                        8.0, EntityAttributeModifier.Operation.ADD_VALUE),
                                AttributeModifierSlot.MAINHAND)
                        .build()
        ));
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        if (!world.isClient) {
            throwShield(player, (ServerWorld) world);
        }
        player.getItemCooldownManager().set(this, 30);
        return TypedActionResult.success(player.getStackInHand(hand));
    }

    private void throwShield(PlayerEntity player, ServerWorld world) {
        Vec3d look = player.getRotationVec(1.0f);
        // Use a snowball as a stand-in projectile; replace with custom entity for real visuals
        SnowballEntity snowball = new SnowballEntity(world, player);
        snowball.setVelocity(look.x * 3.0, look.y * 3.0, look.z * 3.0);
        world.spawnEntity(snowball);
        world.playSound(null, player.getBlockPos(),
                SoundEvents.ITEM_SHIELD_BLOCK, SoundCategory.PLAYERS, 1.0f, 1.0f);
    }
}
