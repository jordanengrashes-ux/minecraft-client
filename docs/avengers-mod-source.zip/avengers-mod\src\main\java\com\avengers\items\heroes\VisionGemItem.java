package com.avengers.items.heroes;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class VisionGemItem extends Item {

    public VisionGemItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient) {
            if (player.isSneaking()) {
                // Phase — teleport 5 blocks forward through obstacles
                Vec3d look = player.getRotationVec(1.0f).multiply(5.0);
                Vec3d dest = player.getPos().add(look);
                player.teleport((ServerWorld) world,
                        dest.x, dest.y, dest.z,
                        java.util.Set.of(), player.getYaw(), player.getPitch());
                player.fallDistance = 0;
                world.playSound(null, player.getBlockPos(),
                        SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 0.5f, 1.5f);
            } else {
                // Mind Stone beam — high-power fireball in look direction
                Vec3d look = player.getRotationVec(1.0f);
                Vec3d pos = player.getEyePos();
                FireballEntity beam = new FireballEntity(world, player, look.multiply(3), 3);
                beam.setPosition(pos.x + look.x, pos.y + look.y, pos.z + look.z);
                world.spawnEntity(beam);
                world.playSound(null, player.getBlockPos(),
                        SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1.0f, 0.7f);
            }
            stack.damage(1, player, net.minecraft.entity.EquipmentSlot.MAINHAND);
        }
        player.getItemCooldownManager().set(this, 15);
        return TypedActionResult.success(stack);
    }
}
