package com.avengers.items.heroes;

import net.minecraft.component.type.ItemAttributeModifiers;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public class MjolnirItem extends Item {

    public MjolnirItem(Settings settings) {
        super(settings.attributeModifiers(buildModifiers()));
    }

    private static ItemAttributeModifiers buildModifiers() {
        return ItemAttributeModifiers.builder()
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE,
                        new EntityAttributeModifier(
                                Identifier.of("avengers", "mjolnir_damage"),
                                10.0, EntityAttributeModifier.Operation.ADD_VALUE),
                        AttributeModifierSlot.MAINHAND)
                .add(EntityAttributes.GENERIC_ATTACK_SPEED,
                        new EntityAttributeModifier(
                                Identifier.of("avengers", "mjolnir_speed"),
                                -2.4, EntityAttributeModifier.Operation.ADD_VALUE),
                        AttributeModifierSlot.MAINHAND)
                .build();
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (attacker.getWorld() instanceof ServerWorld serverWorld) {
            net.minecraft.entity.LightningEntity lightning =
                    new net.minecraft.entity.LightningEntity(
                            net.minecraft.entity.EntityType.LIGHTNING_BOLT, serverWorld);
            lightning.setPosition(target.getX(), target.getY(), target.getZ());
            serverWorld.spawnEntity(lightning);
        }
        stack.damage(1, attacker, net.minecraft.entity.EquipmentSlot.MAINHAND);
        return true;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        if (!world.isClient) {
            // Airborne boost — levitate upward
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 40, 2, false, false));
            world.playSound(null, player.getBlockPos(),
                    SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 0.6f, 1.2f);
        }
        return TypedActionResult.success(player.getStackInHand(hand));
    }

    @Override
    public boolean isSuitableFor(ItemStack stack, net.minecraft.block.BlockState state) {
        return false;
    }
}
