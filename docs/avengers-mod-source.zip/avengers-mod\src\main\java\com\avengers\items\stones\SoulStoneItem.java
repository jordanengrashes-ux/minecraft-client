package com.avengers.items.stones;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

import java.util.List;

public class SoulStoneItem extends BaseStoneItem {

    public SoulStoneItem(Settings settings) {
        super(settings);
    }

    @Override
    protected void activatePower(World world, PlayerEntity player) {
        // Apply Glowing to nearby entities (see-through-walls effect)
        List<Entity> nearby = world.getOtherEntities(player, player.getBoundingBox().expand(20.0));
        for (Entity e : nearby) {
            if (e instanceof LivingEntity living) {
                living.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.GLOWING, 400, 0, false, false));
            }
        }
        // Restore player health
        player.setHealth(Math.min(player.getMaxHealth(), player.getHealth() + 10.0f));
        world.playSound(null, player.getBlockPos(),
                SoundEvents.ENTITY_ELDER_GUARDIAN_CURSE, SoundCategory.PLAYERS, 0.5f, 0.8f);
    }

    @Override
    protected int getCooldown() { return 200; }
}
