package com.avengers.items.stones;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

import java.util.List;

public class TimeStoneItem extends BaseStoneItem {

    public TimeStoneItem(Settings settings) {
        super(settings);
    }

    @Override
    protected void activatePower(World world, PlayerEntity player) {
        // Slow all nearby hostile entities
        List<Entity> nearby = world.getOtherEntities(player, player.getBoundingBox().expand(12.0));
        for (Entity e : nearby) {
            if (e instanceof LivingEntity living && !(living instanceof PlayerEntity)) {
                living.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.SLOWNESS, 200, 9, false, true));
                living.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.MINING_FATIGUE, 200, 9, false, false));
            }
        }
        if (world instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.REVERSE_PORTAL,
                    player.getX(), player.getY() + 1, player.getZ(),
                    40, 2.0, 2.0, 2.0, 0.1);
        }
        world.playSound(null, player.getBlockPos(),
                SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 0.8f, 0.5f);
    }

    @Override
    protected int getCooldown() { return 100; }
}
