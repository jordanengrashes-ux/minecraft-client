package com.avengers.entities;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.IronGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class UltronEntity extends HostileEntity {

    private final ServerBossBar bossBar = new ServerBossBar(
            Text.literal("Ultron"), BossBar.Color.RED, BossBar.Style.NOTCHED_10);

    private int laserCooldown = 0;
    private int droneCooldown = 0;

    public UltronEntity(EntityType<? extends UltronEntity> type, World world) {
        super(type, world);
        this.setHealth(300.0f);
        this.experiencePoints = 300;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 300.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 10.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28)
                .add(EntityAttributes.GENERIC_ARMOR, 8.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.5)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new MeleeAttackGoal(this, 1.2, true));
        this.goalSelector.add(2, new WanderAroundFarGoal(this, 0.8));
        this.goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 16.0f));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        bossBar.setPercent(this.getHealth() / this.getMaxHealth());

        if (!this.getWorld().isClient) {
            if (laserCooldown-- <= 0 && this.getTarget() != null) {
                fireLaser();
                laserCooldown = 40;
            }
            if (droneCooldown-- <= 0) {
                spawnDrone();
                droneCooldown = 300;
            }
        }
    }

    private void fireLaser() {
        if (this.getTarget() == null) return;
        Vec3d dir = this.getTarget().getEyePos().subtract(this.getEyePos()).normalize();
        FireballEntity laser = new FireballEntity(this.getWorld(), this, dir.multiply(2), 0);
        laser.setPosition(this.getX() + dir.x, this.getEyeY(), this.getZ() + dir.z);
        this.getWorld().spawnEntity(laser);
        this.getWorld().playSound(null, this.getBlockPos(),
                SoundEvents.ENTITY_BLAZE_SHOOT, net.minecraft.sound.SoundCategory.HOSTILE, 0.5f, 1.8f);
    }

    private void spawnDrone() {
        if (!(this.getWorld() instanceof ServerWorld sw)) return;
        // Spawns an Iron Golem as a stand-in drone (replace with custom entity for full experience)
        IronGolemEntity drone = EntityType.IRON_GOLEM.create(sw, SpawnReason.MOB_SUMMONED);
        if (drone == null) return;
        drone.setPosition(this.getPos().add(
                (this.getRandom().nextDouble() - 0.5) * 6, 0,
                (this.getRandom().nextDouble() - 0.5) * 6));
        drone.setCustomName(Text.literal("Ultron Drone"));
        sw.spawnEntity(drone);
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        bossBar.removePlayer(player);
    }

    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_IRON_GOLEM_HURT; }

    @Override
    protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource source) {
        return SoundEvents.ENTITY_IRON_GOLEM_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_IRON_GOLEM_DEATH; }
}
