package com.avengers.items.stones;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

public class PowerStoneItem extends BaseStoneItem {

    public PowerStoneItem(Settings settings) {
        super(settings);
    }

    @Override
    protected void activatePower(World world, PlayerEntity player) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 600, 4, false, true));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 600, 2, false, true));
        world.playSound(null, player.getBlockPos(),
                SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.PLAYERS, 0.6f, 1.2f);
    }

    @Override
    protected int getCooldown() { return 600; }
}
