package com.avengers.registry;

import com.avengers.AvengersMain;
import com.avengers.entities.LokiEntity;
import com.avengers.entities.ThanosEntity;
import com.avengers.entities.UltronEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {

    public static final EntityType<ThanosEntity> THANOS = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(AvengersMain.MOD_ID, "thanos"),
            EntityType.Builder.create(ThanosEntity::new, SpawnGroup.MONSTER)
                    .dimensions(1.4f, 3.5f)
                    .build()
    );

    public static final EntityType<LokiEntity> LOKI = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(AvengersMain.MOD_ID, "loki"),
            EntityType.Builder.create(LokiEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.95f)
                    .build()
    );

    public static final EntityType<UltronEntity> ULTRON = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(AvengersMain.MOD_ID, "ultron"),
            EntityType.Builder.create(UltronEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.95f)
                    .build()
    );

    public static void initialize() {
        FabricDefaultAttributeRegistry.register(THANOS, ThanosEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(LOKI, LokiEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(ULTRON, UltronEntity.createAttributes());
    }
}
