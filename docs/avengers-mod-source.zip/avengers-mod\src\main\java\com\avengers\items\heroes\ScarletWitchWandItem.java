package com.avengers.items.heroes;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.DragonFireballEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;

public class ScarletWitchWandItem extends Item {

    public ScarletWitchWandItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient) {
            if (player.isSneaking()) {
                // AOE chaos burst — push nearby entities
                List<Entity> nearby = world.getOtherEntities(player,
                        player.getBoundingBox().expand(6.0));
                for (Entity e : nearby) {
                    Vec3d dir = e.getPos().subtract(player.getPos()).normalize();
                    e.addVelocity(dir.x * 2.0, 0.8, dir.z * 2.0);
                    if (e instanceof LivingEntity living) {
                        living.takeKnockback(2.0f, -dir.x, -dir.z);
                    }
                }
                world.playSound(null, player.getBlockPos(),
                        SoundEvents.ENTITY_ENDER_DRAGON_GROWL, SoundCategory.PLAYERS, 0.5f, 1.5f);
            } else {
                // Launch magic projectile
                Vec3d look = player.getRotationVec(1.0f);
                Vec3d pos = player.getEyePos();
                DragonFireballEntity fireball = new DragonFireballEntity(
                        (ServerWorld) world, player, look.multiply(2));
                fireball.setPosition(pos.x + look.x, pos.y + look.y, pos.z + look.z);
                world.spawnEntity(fireball);
                world.playSound(null, player.getBlockPos(),
                        SoundEvents.ENTITY_ENDER_EYE_LAUNCH, SoundCategory.PLAYERS, 1.0f, 1.0f);
            }
            stack.damage(1, player, net.minecraft.entity.EquipmentSlot.MAINHAND);
        }
        player.getItemCooldownManager().set(this, 10);
        return TypedActionResult.success(stack);
    }
}
