package com.avengers.registry;

import com.avengers.AvengersMain;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public class ModArmorMaterials {

    public static final RegistryEntry<ArmorMaterial> IRON_MAN = register(
            "iron_man",
            Map.of(ArmorItem.Type.HELMET, 4, ArmorItem.Type.CHESTPLATE, 9,
                   ArmorItem.Type.LEGGINGS, 7, ArmorItem.Type.BOOTS, 4),
            20, SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE,
            () -> Ingredient.ofItems(Items.NETHERITE_INGOT), 4.0f, 0.3f
    );

    public static final RegistryEntry<ArmorMaterial> BLACK_PANTHER = register(
            "black_panther",
            Map.of(ArmorItem.Type.HELMET, 3, ArmorItem.Type.CHESTPLATE, 8,
                   ArmorItem.Type.LEGGINGS, 6, ArmorItem.Type.BOOTS, 3),
            15, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND,
            () -> Ingredient.ofItems(Items.DIAMOND), 2.0f, 0.2f
    );

    public static final RegistryEntry<ArmorMaterial> FALCON = register(
            "falcon",
            Map.of(ArmorItem.Type.HELMET, 2, ArmorItem.Type.CHESTPLATE, 6,
                   ArmorItem.Type.LEGGINGS, 5, ArmorItem.Type.BOOTS, 2),
            12, SoundEvents.ITEM_ARMOR_EQUIP_IRON,
            () -> Ingredient.ofItems(Items.IRON_INGOT), 1.0f, 0.1f
    );

    private static RegistryEntry<ArmorMaterial> register(
            String name, Map<ArmorItem.Type, Integer> defense, int enchantability,
            net.minecraft.sound.SoundEvent equipSound, Supplier<Ingredient> repair,
            float toughness, float knockback) {

        EnumMap<ArmorItem.Type, Integer> map = new EnumMap<>(ArmorItem.Type.class);
        for (ArmorItem.Type type : ArmorItem.Type.values()) {
            map.put(type, defense.getOrDefault(type, 0));
        }
        List<ArmorMaterial.Layer> layers = List.of(
                new ArmorMaterial.Layer(Identifier.of(AvengersMain.MOD_ID, name))
        );
        return Registry.registerReference(
                Registries.ARMOR_MATERIAL,
                Identifier.of(AvengersMain.MOD_ID, name),
                new ArmorMaterial(map, enchantability, equipSound, repair, layers, toughness, knockback)
        );
    }

    public static void initialize() {}
}
