package com.avengers.items.heroes;

import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class PymParticlesItem extends Item {

    private static final String NBT_KEY = "pym_state";

    public PymParticlesItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient) {
            var scaleAttr = player.getAttributeInstance(EntityAttributes.GENERIC_SCALE);
            if (scaleAttr == null) {
                player.sendMessage(Text.literal("Scale attribute not available."), true);
                return TypedActionResult.pass(stack);
            }

            double current = scaleAttr.getBaseValue();
            if (Math.abs(current - 1.0) < 0.01) {
                if (player.isSneaking()) {
                    // Shrink
                    scaleAttr.setBaseValue(0.25);
                    player.sendMessage(Text.literal("Going sub-atomic!"), true);
                } else {
                    // Grow
                    scaleAttr.setBaseValue(3.0);
                    player.sendMessage(Text.literal("Growing giant!"), true);
                }
            } else {
                // Return to normal
                scaleAttr.setBaseValue(1.0);
                player.sendMessage(Text.literal("Back to normal size."), true);
            }
            world.playSound(null, player.getBlockPos(),
                    SoundEvents.ITEM_BOTTLE_EMPTY, SoundCategory.PLAYERS, 1.0f, current < 1.0 ? 0.5f : 1.5f);
        }
        player.getItemCooldownManager().set(this, 20);
        return TypedActionResult.success(stack);
    }
}
