package com.avengers;

import com.avengers.registry.ModEntities;
import com.avengers.registry.ModItemGroups;
import com.avengers.registry.ModItems;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AvengersMain implements ModInitializer {
    public static final String MOD_ID = "avengers";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.initialize();
        ModEntities.initialize();
        ModItemGroups.initialize();
        registerFlightTick();
        LOGGER.info("Avengers Assemble!");
    }

    private void registerFlightTick() {
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            for (ServerPlayerEntity player : world.getPlayers()) {
                if (player.isCreative() || player.isSpectator()) continue;

                boolean canFly = ModItems.hasFullIronManSuit(player)
                        || ModItems.hasFalconWings(player);

                if (canFly) {
                    if (!player.getAbilities().allowFlying) {
                        player.getAbilities().allowFlying = true;
                        player.sendAbilitiesUpdate();
                    }
                } else {
                    if (player.getAbilities().allowFlying) {
                        player.getAbilities().allowFlying = false;
                        if (player.getAbilities().flying) {
                            player.getAbilities().flying = false;
                            player.fallDistance = 0;
                        }
                        player.sendAbilitiesUpdate();
                    }
                }
            }
        });
    }
}
