package com.avengers.mixin;

import com.avengers.registry.ModItems;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {

    /**
     * Suppress fall damage when Iron Man suit is fully equipped or Falcon Wings are worn.
     */
    @Inject(method = "handleFallDamage", at = @At("HEAD"), cancellable = true)
    private void onFallDamage(float fallDistance, float damageMultiplier,
                               net.minecraft.entity.damage.DamageSource source,
                               CallbackInfo ci) {
        PlayerEntity player = (PlayerEntity) (Object) this;
        if (player.getWorld().isClient) return;
        if (player instanceof net.minecraft.server.network.ServerPlayerEntity sp) {
            if (ModItems.hasFullIronManSuit(sp) || ModItems.hasFalconWings(sp)) {
                ci.cancel();
            }
        }
    }
}
