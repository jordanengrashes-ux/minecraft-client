package com.avengers.items.heroes;

import com.avengers.AvengersMain;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.ItemAttributeModifiers;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public class BlackWidowBatonsItem extends Item {

    public BlackWidowBatonsItem(Settings settings) {
        super(settings.attributeModifiers(
                ItemAttributeModifiers.builder()
                        .add(EntityAttributes.GENERIC_ATTACK_DAMAGE,
                                new EntityAttributeModifier(
                                        Identifier.of(AvengersMain.MOD_ID, "baton_damage"),
                                        5.0, EntityAttributeModifier.Operation.ADD_VALUE),
                                AttributeModifierSlot.MAINHAND)
                        .add(EntityAttributes.GENERIC_ATTACK_SPEED,
                                new EntityAttributeModifier(
                                        Identifier.of(AvengersMain.MOD_ID, "baton_speed"),
                                        1.6, EntityAttributeModifier.Operation.ADD_VALUE),
                                AttributeModifierSlot.MAINHAND)
                        .build()
        ));
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        // Electric shock — Slowness + Weakness
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1, false, true));
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 60, 0, false, true));
        World world = target.getWorld();
        world.playSound(null, target.getBlockPos(),
                SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, SoundCategory.PLAYERS, 0.3f, 2.0f);
        stack.damage(1, attacker, net.minecraft.entity.EquipmentSlot.MAINHAND);
        return true;
    }
}
