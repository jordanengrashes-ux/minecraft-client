package com.avengers.items.heroes;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class HulkSerumItem extends Item {

    private static final int HULK_DURATION = 6000; // 5 minutes

    public HulkSerumItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient) {
            boolean isHulk = player.hasStatusEffect(StatusEffects.STRENGTH);
            if (isHulk) {
                revert(player);
                player.sendMessage(Text.literal("Banner regains control."), true);
            } else {
                transform(player);
                player.sendMessage(Text.literal("HULK SMASH!"), true);
            }
            world.playSound(null, player.getBlockPos(),
                    SoundEvents.ENTITY_RAVAGER_ROAR, SoundCategory.PLAYERS, 1.0f, 0.5f);
        }
        return TypedActionResult.success(stack);
    }

    private void transform(PlayerEntity player) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, HULK_DURATION, 4, false, false));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, HULK_DURATION, 3, false, false));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, HULK_DURATION, 3, false, false));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, HULK_DURATION, 1, false, false));
        // Scale up if the attribute exists
        var scaleAttr = player.getAttributeInstance(EntityAttributes.GENERIC_SCALE);
        if (scaleAttr != null) scaleAttr.setBaseValue(2.5);
    }

    private void revert(PlayerEntity player) {
        player.removeStatusEffect(StatusEffects.STRENGTH);
        player.removeStatusEffect(StatusEffects.JUMP_BOOST);
        player.removeStatusEffect(StatusEffects.RESISTANCE);
        player.removeStatusEffect(StatusEffects.REGENERATION);
        var scaleAttr = player.getAttributeInstance(EntityAttributes.GENERIC_SCALE);
        if (scaleAttr != null) scaleAttr.setBaseValue(1.0);
    }
}
