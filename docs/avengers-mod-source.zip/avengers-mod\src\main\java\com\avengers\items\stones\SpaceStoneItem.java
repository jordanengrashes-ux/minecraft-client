package com.avengers.items.stones;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class SpaceStoneItem extends BaseStoneItem {

    private static final double RANGE = 50.0;

    public SpaceStoneItem(Settings settings) {
        super(settings);
    }

    @Override
    protected void activatePower(World world, PlayerEntity player) {
        Vec3d dest = player.getPos().add(player.getRotationVec(1.0f).multiply(RANGE));
        if (world instanceof ServerWorld sw) {
            player.teleport(sw, dest.x, dest.y, dest.z,
                    java.util.Set.of(), player.getYaw(), player.getPitch());
            player.fallDistance = 0;
            sw.spawnParticles(ParticleTypes.PORTAL,
                    dest.x, dest.y + 1, dest.z, 50, 1.0, 1.0, 1.0, 0.2);
        }
        world.playSound(null, player.getBlockPos(),
                SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0f, 0.6f);
    }

    @Override
    protected int getCooldown() { return 60; }
}
